exports.handler = async (event) => {
    // TODO implement
    var fecha = function (fn){
        return moment(date.getTime()).tz("America/Mexico_City").format("YYYY-MM-DD HH:mm:SS");
    }
    console.log("Fecha", fecha);

    const response = {
        statusCode: 200,
        body: fecha,
    };
    return response;
};
