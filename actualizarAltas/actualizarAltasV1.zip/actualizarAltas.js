var AWS = require('aws-sdk');
var mysql = require('mysql');
var moment = require("moment-timezone");

const {
    convertArrayToCSV
} = require('convert-array-to-csv');

exports.handler = function (event, context, callback) {
    //Conexión al S3 - posterior al sftp/////////////
    var filePath = 'your_file_path';
            var s3 = new AWS.S3();
            var getParams = {
                Bucket: 'clienteskof',
                // Body: csvFromArrayOfArrays,
                Key: "oficina_movil_FEMSA.csv"
            };
            s3.getObject(getParams, function (err, data) {
                if (err) {
                    console.log("Error", err);
                }
                if (data) {
                    console.log("Upload Success", data.Location);
                }
            });
    const response = {
        statusCode: 200,
        body: JSON.stringify('Datos cargados'),
    };
    return response;
};