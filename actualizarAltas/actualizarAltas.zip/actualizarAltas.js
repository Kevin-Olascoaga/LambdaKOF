var AWS = require('aws-sdk');
var mysql = require('mysql');
// var moment = require("moment-timezone");
const csv = require('csvtojson');

exports.handler = function (event, context, callback) {
    //Conexión al S3 - posterior al sftp/////////////
    var filePath = 'your_file_path';
    var s3 = new AWS.S3();
    var getParams = {
        Bucket: 'clienteskof',
        // Body: csvFromArrayOfArrays,
        Key: "SAP_oficina_movil_FEMSA.csv"
    };
    async function csvToJSON() {
        // get csv file and create stream
        const stream = s3.getObject(getParams).createReadStream();
        // convert csv file (stream) to JSON format data
        const json = await csv().fromStream(stream);
        console.log(json);
        for (let i = 0; i < json.length; i++) {
            console.log(json[i]);
        }
    };
    csvToJSON();
    // s3.getObject(getParams, function (err, data) {
    //     if (err) {
    //         console.log("Error", err);
    //     }
    //     if (data) {


    //         let json = csvToJson.getJsonFromCsv(data.body);
    //         console.log("Objeto: ", json);
    //         for(let i=0; i<json.length;i++){
    //             console.log(json[i]);
    //         }
    //     }
    // });
    const response = {
        statusCode: 200,
        body: JSON.stringify('Datos cargados'),
    };
    return response;
};