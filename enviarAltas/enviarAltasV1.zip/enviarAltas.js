var AWS = require('aws-sdk');
var mysql = require('mysql');
const { convertArrayToCSV } = require('convert-array-to-csv');

var generarArchivoS3 = function(next, results) {    
    //Conexión Base de datos///////////////////
    var connection = mysql.createConnection({
        host: "kof.cmk4tzokwqsd.us-west-2.rds.amazonaws.com",
        user: "kofadmin",
        password: "CyEoDDTWfCtPY7h3NKzB",
        port: 3306,
        database: "innodb",
    });
    connection.connect(function (err) {
        if (err) {
            console.error('Database connection failed : ' + err.stack);
            return;
        }
        console.log('Conexión a la base de datos');
        let hoy = new Date();
        let diaF = hoy.getDate();
        let mesF = hoy.getMonth()+1;
        let añoF = hoy.getFullYear();
        let ayer = new Date();
        ayer.setDate(ayer.getDate() - 1);
        let diaI = ayer.getDate();
        let mesI = ayer.getMonth()+1;
        let añoI = ayer.getFullYear();
        
        // let fechaInicio = new Date(añoI,mesI,diaI,17);
        fechaInicio = añoI + "-" + mesI + "-" + diaI + " 17:00:00";
        // let fechaFin = new Date(añoF,mesF,diaF,17);
        fechaFin = añoF + "-" + mesF + "-" + diaF + " 17:00:00";
        var tablaClientes = "SELECT * FROM prueba WHERE fechaSolicitud >= '" + fechaFin + "'";
        connection.query(tablaClientes, function (err, result) {
            if (err) throw err;
            const header = ['PEDIDO', 'FECHA ENTREGA', 'CLIENTE', 'RESPONSABLE DE PAGO', 'DESTINATARIO DE MERCANCIA', 'FECHA DEL PEDIDO', 'MATERIAL', 'CANTIDAD', 'UM', 'TIPO OPERACIÓN', 'VPT'];
            const csvFromArrayOfArrays = convertArrayToCSV(result, {
                header,
                separator: ','
            });
            //Conexión S3//////////////////////////////
            var filePath = 'your_file_path';
            var s3 = new AWS.S3();
            var uploadParams = {
                Bucket: 'clienteskof',
                Body: csvFromArrayOfArrays,
                Key: "Clientes_" + fechaFin + ".csv"
            };
            s3.upload (uploadParams, function (err, data) {
                if (err) {
                  console.log("Error", err);
                } if (data) {
                  console.log("Upload Success", data.Location);
                }
              });
        });
    });
};
var getS3UploadedCSVFileContent = function(next, results) {
    var filePath = 'your_file_path';
    var s3 = new AWS.S3();
    var params = {
        Bucket: 'clienteskof',
        Key: filePath
    }
    s3.getObject(params, function(err, data) {
        if (err) {
            console.log("Error in getting CSV file from S3 bucket", err);
        } else {
            console.log("Content is", data);
            var dataObject = data.Body.toString();
            next(null, dataObject);
        }
    })
};
var uploadCSVFileOnSftpServer = function(next, s3FileStreamContent) {
    var filePath = 'your_file_path';
    var Client = require('ssh2').Client;
    var connSettings = {
        host: 'your_server_host_name',
        port: 22,
        username: 'user_name',
        password: 'password'
    };
    var conn = new Client();
    conn.on('ready', function() {
        conn.sftp(function(err, sftp) {
            if (err) {
                console.log("Errror in connection", err);
            } else {
                console.log("Connection established", sftp);
                var options = Object.assign({}, {
                    encoding: 'utf-8'
                }, true);
                var stream = sftp.createWriteStream(filePath, options);
                var data = stream.end(s3FileStreamContent);
                stream.on('close', function() {
                    console.log("- file transferred succesfully");
                    conn.end();
                    next(null, true);
                });
            }
        });
    }).connect(connSettings);
};
exports.handler = async (event, context, callback) => {
    generarArchivoS3();
    //getS3UploadedCSVFileContent();
    //uploadCSVFileOnSftpServer();
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
